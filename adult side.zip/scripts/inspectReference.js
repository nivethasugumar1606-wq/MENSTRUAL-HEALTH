import sharp from 'sharp';
import fs from 'fs';
import path from 'path';

const img1 = 'C:/Users/DELL/.gemini/antigravity-ide/brain/6bdda1c2-6460-4c7d-8a6f-ea07428974b9/.user_uploaded/media_1792765786465.jpg';
const img2 = 'C:/Users/DELL/.gemini/antigravity-ide/brain/6bdda1c2-6460-4c7d-8a6f-ea07428974b9/.user_uploaded/media_1792818453242.png';

async function main() {
  const meta1 = await sharp(img1).metadata();
  console.log('Image 1 (JPG):', meta1.width, 'x', meta1.height);

  let meta2 = null;
  if (fs.existsSync(img2)) {
    meta2 = await sharp(img2).metadata();
    console.log('Image 2 (PNG):', meta2.width, 'x', meta2.height);
  }
}

main().catch(console.error);
