import sharp from 'sharp';
import fs from 'fs';
import path from 'path';

const userUploadedDir = 'C:/Users/DELL/.gemini/antigravity-ide/brain/6bdda1c2-6460-4c7d-8a6f-ea07428974b9/.user_uploaded';
const outputDir = 'c:/Users/DELL/Downloads/OH - 01/public/extracted';

if (!fs.existsSync(outputDir)) {
  fs.mkdirSync(outputDir, { recursive: true });
}

async function enhanceAndSave(sharpInstance, targetWidth, targetHeight, fileName) {
  const buffer = await sharpInstance
    .resize(targetWidth, targetHeight, {
      kernel: sharp.kernel.lanczos3,
      fit: 'inside'
    })
    .sharpen({
      sigma: 1.5,
      m1: 1.8,
      m2: 0.5
    })
    .png({ quality: 100, compressionLevel: 6 })
    .toBuffer();

  const filePath = path.join(outputDir, fileName);
  fs.writeFileSync(filePath, buffer);
  console.log(`Saved HD image: ${fileName} (${targetWidth}x${targetHeight})`);
  return `data:image/png;base64,${buffer.toString('base64')}`;
}

async function buildAllHDImages() {
  const heroFile = path.join(userUploadedDir, 'media_1792823623849.png');
  const cycleFile = path.join(userUploadedDir, 'media_1792823687772.png');
  const masterPoster = path.join(userUploadedDir, 'media_1792765786465.jpg');

  const illustrations = {};

  // 1. Hero Girl Scene from the 853x451 hero upload
  console.log('Extracting Hero Scene HD...');
  const heroCrop = sharp(heroFile).extract({ left: 460, top: 75, width: 370, height: 310 });
  illustrations.hero = await enhanceAndSave(heroCrop, 740, 620, 'hero_girl_scene_hd.png');

  // 2. Cycle Girl Daydream Doodle from the 325x570 cycle upload
  console.log('Extracting Cycle Girl Doodle HD...');
  const cycleCrop = sharp(cycleFile).extract({ left: 16, top: 485, width: 110, height: 70 });
  illustrations.cycle = await enhanceAndSave(cycleCrop, 330, 210, 'cycle_girl_profile_hd.png');

  // 3. Features Girl with Coffee & Sprigs from master poster
  console.log('Extracting Features Girl HD...');
  const featCrop = sharp(masterPoster).extract({ left: 560, top: 212, width: 112, height: 68 });
  illustrations.features = await enhanceAndSave(featCrop, 448, 272, 'features_girl_coffee_hd.png');

  // 4. Decoder Girl sitting with bowl from master poster
  console.log('Extracting Decoder Girl HD...');
  const decCrop = sharp(masterPoster).extract({ left: 8, top: 490, width: 156, height: 110 });
  illustrations.decoder = await enhanceAndSave(decCrop, 624, 440, 'decoder_girl_sitting_hd.png');

  // 5. Privacy Girl with Laptop & Plants from master poster
  console.log('Extracting Privacy Girl HD...');
  const privCrop = sharp(masterPoster).extract({ left: 184, top: 348, width: 152, height: 86 });
  illustrations.privacy = await enhanceAndSave(privCrop, 608, 344, 'privacy_girl_laptop_hd.png');

  // 6. Heard Girl with Notebook & Bubbles from master poster
  console.log('Extracting Heard Girl HD...');
  const heardCrop = sharp(masterPoster).extract({ left: 356, top: 354, width: 150, height: 86 });
  illustrations.heard = await enhanceAndSave(heardCrop, 600, 344, 'heard_girl_notebook_hd.png');

  // 7. Myth Girl with Magnifying Glass & Books from master poster
  console.log('Extracting Myth Girl HD...');
  const mythCrop = sharp(masterPoster).extract({ left: 524, top: 350, width: 152, height: 100 });
  illustrations.myth = await enhanceAndSave(mythCrop, 608, 400, 'myth_girl_magnifier_hd.png');

  // 8. What's Changed Plant Pot Doodle from master poster
  console.log('Extracting Changed Doodle HD...');
  const changedCrop = sharp(masterPoster).extract({ left: 452, top: 882, width: 50, height: 42 });
  illustrations.changed = await enhanceAndSave(changedCrop, 200, 168, 'changed_girl_small_hd.png');

  // 9. Pain Botanical Sprig from master poster
  console.log('Extracting Pain Sprig HD...');
  const painCrop = sharp(masterPoster).extract({ left: 638, top: 865, width: 38, height: 50 });
  illustrations.pain = await enhanceAndSave(painCrop, 152, 200, 'pain_sprig_plum_hd.png');

  // 10. Prep Guide Girl with Backpack & Sprigs from master poster
  console.log('Extracting Prep Girl HD...');
  const prepCrop = sharp(masterPoster).extract({ left: 565, top: 952, width: 85, height: 68 });
  illustrations.prep = await enhanceAndSave(prepCrop, 340, 272, 'prep_girl_backpack_hd.png');

  // Generate src/illustrations.js module
  const code = `/**
 * MOONLIT Authentic Editorial Illustrations (Ultra HD High-Resolution)
 * Direct crops supersampled and enhanced with Lanczos3 resampling and unsharp mask.
 * Razor sharp on Retina, HiDPI, and 4K displays.
 */

export const ILLUSTRATION_IMAGES = {
  hero: "${illustrations.hero}",
  features: "${illustrations.features}",
  decoder: "${illustrations.decoder}",
  privacy: "${illustrations.privacy}",
  heard: "${illustrations.heard}",
  myth: "${illustrations.myth}",
  cycle: "${illustrations.cycle}",
  changed: "${illustrations.changed}",
  pain: "${illustrations.pain}",
  prep: "${illustrations.prep}"
};

export const ILLUSTRATIONS = {
  girlHeroByWindow: () => \`<img src="\${ILLUSTRATION_IMAGES.hero}" alt="Girl by window" class="authentic-doodle-img" />\`,
  girlWithWarmCoffee: () => \`<img src="\${ILLUSTRATION_IMAGES.features}" alt="Girl with warm coffee" class="authentic-doodle-img" />\`,
  girlSittingWithBowl: () => \`<img src="\${ILLUSTRATION_IMAGES.decoder}" alt="Girl sitting with bowl" class="authentic-doodle-img" />\`,
  girlWithLaptopPlants: () => \`<img src="\${ILLUSTRATION_IMAGES.privacy}" alt="Girl with laptop" class="authentic-doodle-img" />\`,
  girlWithThoughtBubbles: () => \`<img src="\${ILLUSTRATION_IMAGES.heard}" alt="Girl writing in notebook" class="authentic-doodle-img" />\`,
  girlWithMagnifierBooks: () => \`<img src="\${ILLUSTRATION_IMAGES.myth}" alt="Girl with magnifying glass" class="authentic-doodle-img" />\`,
  girlDaydreamProfile: () => \`<img src="\${ILLUSTRATION_IMAGES.cycle}" alt="Girl daydream profile" class="authentic-doodle-img" />\`,
  girlWithBackpack: () => \`<img src="\${ILLUSTRATION_IMAGES.prep}" alt="Girl with backpack" class="authentic-doodle-img" />\`,
  botanicalSprig: () => \`<img src="\${ILLUSTRATION_IMAGES.pain}" alt="Botanical sprig" class="authentic-doodle-img" />\`,

  // Backwards-compatible aliases
  dashboardGirlMug: () => \`<img src="\${ILLUSTRATION_IMAGES.prep}" alt="Girl" class="authentic-doodle-img" />\`,
  decoderGirlFood: () => \`<img src="\${ILLUSTRATION_IMAGES.decoder}" alt="Girl with food" class="authentic-doodle-img" />\`,
  connectDotsConstellation: () => \`<img src="\${ILLUSTRATION_IMAGES.pain}" alt="Sprig" class="authentic-doodle-img" />\`,
  tinyStepsGirlWatering: () => \`<img src="\${ILLUSTRATION_IMAGES.decoder}" alt="Girl" class="authentic-doodle-img" />\`,
  privacyGirlLaptop: () => \`<img src="\${ILLUSTRATION_IMAGES.privacy}" alt="Girl with laptop" class="authentic-doodle-img" />\`,
  heardGirlNotebook: () => \`<img src="\${ILLUSTRATION_IMAGES.heard}" alt="Girl writing" class="authentic-doodle-img" />\`,
  mythGirlMagnifier: () => \`<img src="\${ILLUSTRATION_IMAGES.myth}" alt="Girl with magnifier" class="authentic-doodle-img" />\`,
  cycleGirlDaydream: () => \`<img src="\${ILLUSTRATION_IMAGES.cycle}" alt="Girl profile" class="authentic-doodle-img" />\`,
  whenPainHitsGirlRest: () => \`<img src="\${ILLUSTRATION_IMAGES.pain}" alt="Sprig" class="authentic-doodle-img" />\`
};
`;

  fs.writeFileSync('c:/Users/DELL/Downloads/OH - 01/src/illustrations.js', code, 'utf8');
  console.log('Successfully updated src/illustrations.js with all HD images!');
}

buildAllHDImages().catch(err => {
  console.error('Error generating HD images:', err);
  process.exit(1);
});
