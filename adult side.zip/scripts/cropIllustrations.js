import sharp from 'sharp';
import fs from 'fs';
import path from 'path';

const imgPath = 'C:/Users/DELL/.gemini/antigravity-ide/brain/6bdda1c2-6460-4c7d-8a6f-ea07428974b9/.user_uploaded/media_1792765786465.jpg';
const outDir = 'c:/Users/DELL/Downloads/OH - 01/public/extracted';

if (!fs.existsSync(outDir)) {
  fs.mkdirSync(outDir, { recursive: true });
}

// Pixel-perfect crops without any clipping or bleed
const crops = [
  // 1. Hero Girl Reading
  { name: 'hero_girl_scene', left: 185, top: 38, width: 280, height: 236 },
  
  // 2. Features: Girl sipping coffee/tea with plants, heart and stars
  { name: 'features_girl_coffee', left: 560, top: 212, width: 112, height: 68 },
  
  // 3. Card 01: Girl sitting with bowl/notebook, plants, and "Good food is self care ♡"
  { name: 'decoder_girl_sitting', left: 8, top: 490, width: 156, height: 110 },
  
  // 4. Card 02: Girl typing on laptop with cat and desk plants
  { name: 'privacy_girl_laptop', left: 184, top: 348, width: 152, height: 86 },
  
  // 5. Card 03: Girl with wavy hair holding notebook, listening with speech bubble
  { name: 'heard_girl_notebook', left: 356, top: 354, width: 150, height: 86 },
  
  // 6. Card 04: Girl with magnifying glass, stars, books, and branch
  { name: 'myth_girl_magnifier', left: 524, top: 350, width: 152, height: 100 },
  
  // 7. Card 05: Girl profile looking up with stars & sprig
  { name: 'cycle_girl_profile', left: 16, top: 872, width: 92, height: 54 },
  
  // 8. Card 07: Small girl profile doodle in What's Changed
  { name: 'changed_girl_small', left: 452, top: 882, width: 50, height: 42 },
  
  // 9. Card 08: Botanical sprig on dark plum
  { name: 'pain_sprig_plum', left: 638, top: 865, width: 38, height: 50 },

  // 10. Row 4: Girl looking over shoulder with tote bag & flowers
  { name: 'prep_girl_backpack', left: 565, top: 952, width: 85, height: 68 }
];

async function run() {
  for (const c of crops) {
    const outPath = path.join(outDir, `${c.name}.png`);
    await sharp(imgPath)
      .extract({ left: c.left, top: c.top, width: c.width, height: c.height })
      .png()
      .toFile(outPath);
    console.log(`Saved ${c.name}: ${c.width}x${c.height}`);
  }
}

run().catch(console.error);
