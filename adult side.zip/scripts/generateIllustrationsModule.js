import fs from 'fs';
import path from 'path';

const extractedDir = 'c:/Users/DELL/Downloads/OH - 01/public/extracted';
const targetFile = 'c:/Users/DELL/Downloads/OH - 01/src/illustrations.js';

function toBase64(filename) {
  const file = path.join(extractedDir, filename);
  if (!fs.existsSync(file)) return '';
  const buffer = fs.readFileSync(file);
  return `data:image/png;base64,${buffer.toString('base64')}`;
}

const images = {
  hero_girl_scene: toBase64('hero_girl_scene.png'),
  features_girl_coffee: toBase64('features_girl_coffee.png'),
  decoder_girl_sitting: toBase64('decoder_girl_sitting.png'),
  privacy_girl_laptop: toBase64('privacy_girl_laptop.png'),
  heard_girl_notebook: toBase64('heard_girl_notebook.png'),
  myth_girl_magnifier: toBase64('myth_girl_magnifier.png'),
  cycle_girl_profile: toBase64('cycle_girl_profile.png'),
  changed_girl_small: toBase64('changed_girl_small.png'),
  pain_sprig_plum: toBase64('pain_sprig_plum.png'),
  prep_girl_backpack: toBase64('prep_girl_backpack.png')
};

const code = `/**
 * MOONLIT Authentic Editorial Illustrations
 * Pixel-by-pixel direct extraction from the master reference image.
 * Uses high-fidelity inlined base64 data URLs for instantaneous offline rendering.
 */

export const ILLUSTRATION_IMAGES = {
  hero: "${images.hero_girl_scene}",
  features: "${images.features_girl_coffee}",
  decoder: "${images.decoder_girl_sitting}",
  privacy: "${images.privacy_girl_laptop}",
  heard: "${images.heard_girl_notebook}",
  myth: "${images.myth_girl_magnifier}",
  cycle: "${images.cycle_girl_profile}",
  changed: "${images.changed_girl_small}",
  painSprig: "${images.pain_sprig_plum}",
  prep: "${images.prep_girl_backpack}"
};

export const ILLUSTRATIONS = {
  // 1. Hero Girl Reading Scene
  heroGirlReading: (color = '#F8F3EC') => \`
    <div class="illustration-img-wrap hero-img-wrap">
      <img src="\${ILLUSTRATION_IMAGES.hero}" alt="Girl reading on daybed beside starry window" class="authentic-doodle-img hero-img" />
    </div>
  \`,

  // 2. Signature 5 Features: Girl sipping coffee with flowers
  girlWithBackpack: (color = '#473E69') => \`
    <div class="illustration-img-wrap features-img-wrap">
      <img src="\${ILLUSTRATION_IMAGES.features}" alt="Girl with coffee cup and botanicals" class="authentic-doodle-img features-img" />
    </div>
  \`,

  // 3. Body & Food Decoder: Girl sitting with bowl
  girlWithNotebookLap: (color = '#473E69') => \`
    <div class="illustration-img-wrap decoder-img-wrap">
      <img src="\${ILLUSTRATION_IMAGES.decoder}" alt="Girl sitting enjoying nourishing food" class="authentic-doodle-img decoder-img" />
    </div>
  \`,

  // 4. Privacy: Girl working on laptop with cat & plants
  girlWithLaptopPlants: (color = '#473E69') => \`
    <div class="illustration-img-wrap privacy-img-wrap">
      <img src="\${ILLUSTRATION_IMAGES.privacy}" alt="Girl typing on laptop with sleeping cat and desk plants" class="authentic-doodle-img privacy-img" />
    </div>
  \`,

  // 5. Am I Being Heard?: Girl holding notebook with speech bubble
  girlWithThoughtBubbles: (color = '#F8F3EC') => \`
    <div class="illustration-img-wrap heard-img-wrap">
      <img src="\${ILLUSTRATION_IMAGES.heard}" alt="Girl holding medical notebook looking up" class="authentic-doodle-img heard-img" />
    </div>
  \`,

  // 6. Myth Detective: Girl with magnifying glass & books
  girlWithMagnifierBooks: (color = '#473E69') => \`
    <div class="illustration-img-wrap myth-img-wrap">
      <img src="\${ILLUSTRATION_IMAGES.myth}" alt="Girl investigating with magnifying glass and book stack" class="authentic-doodle-img myth-img" />
    </div>
  \`,

  // 7. My Cycle: Girl profile daydreaming
  girlDaydreamProfile: (color = '#473E69') => \`
    <div class="illustration-img-wrap cycle-img-wrap">
      <img src="\${ILLUSTRATION_IMAGES.cycle}" alt="Girl serene profile with stars" class="authentic-doodle-img cycle-img" />
    </div>
  \`,

  // 8. What's Changed Girl Doodle
  changedGirlReflection: (color = '#473E69') => \`
    <div class="illustration-img-wrap changed-img-wrap">
      <img src="\${ILLUSTRATION_IMAGES.changed}" alt="Girl profile doodle" class="authentic-doodle-img changed-img" />
    </div>
  \`,

  // 9. Prep Guide Girl with Tote & Flowers
  prepGuideGirlTote: (color = '#473E69') => \`
    <div class="illustration-img-wrap prep-img-wrap">
      <img src="\${ILLUSTRATION_IMAGES.prep}" alt="Girl with tote bag and flowers" class="authentic-doodle-img prep-img" />
    </div>
  \`,

  // 10. Botanical Sprig
  botanicalSprig: (color = '#473E69') => \`
    <div class="illustration-img-wrap sprig-img-wrap">
      <img src="\${ILLUSTRATION_IMAGES.painSprig}" alt="Botanical sprig" class="authentic-doodle-img sprig-img" />
    </div>
  \`,

  // Backwards-compatible aliases
  dashboardGirlMug: (color = '#473E69') => ILLUSTRATIONS.girlWithBackpack(color),
  decoderGirlFood: (color = '#473E69') => ILLUSTRATIONS.girlWithNotebookLap(color),
  connectDotsConstellation: (color = '#473E69') => ILLUSTRATIONS.botanicalSprig(color),
  tinyStepsGirlWatering: (color = '#473E69') => ILLUSTRATIONS.girlWithNotebookLap(color),
  privacyGirlLaptop: (color = '#473E69') => ILLUSTRATIONS.girlWithLaptopPlants(color),
  heardGirlNotebook: (color = '#F8F3EC') => ILLUSTRATIONS.girlWithThoughtBubbles(color),
  mythGirlMagnifier: (color = '#473E69') => ILLUSTRATIONS.girlWithMagnifierBooks(color),
  cycleGirlDaydream: (color = '#473E69') => ILLUSTRATIONS.girlDaydreamProfile(color),
  whenPainHitsGirlRest: (color = '#F8F3EC') => ILLUSTRATIONS.botanicalSprig(color)
};
`;

fs.writeFileSync(targetFile, code);
console.log('Successfully generated src/illustrations.js with base64 authentic artworks!');
