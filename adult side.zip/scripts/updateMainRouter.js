import fs from 'fs';

const filePath = 'c:/Users/DELL/Downloads/OH - 01/src/main.js';
let content = fs.readFileSync(filePath, 'utf8');

// 1. Change default route in getRouteFromHash
content = content.replace(
  "function getRouteFromHash() {\n  const hash = window.location.hash.replace(/^#\\/?/, '').toLowerCase();\n  return hash || 'board';\n}",
  "function getRouteFromHash() {\n  const hash = window.location.hash.replace(/^#\\/?/, '').toLowerCase();\n  return hash || 'home';\n}"
);

// 2. Replace the isBoardView check in render() to check for isLandingHome
const oldRenderCheck = `  const isBoardView = (currentRoute === 'board' || currentRoute === 'welcome' || currentRoute === '');

  if (isBoardView) {
    document.body.classList.add('route-board');
    appContainer.innerHTML = \`
      <!-- Master Poster Board (Clean, No Clutter, Exact Match to Image) -->
      <main id="main-content" class="board-view-main">
        \${renderMasterBoard(state, cycleMetrics, painMetrics)}
      </main>

      <!-- Discreet Floating Explore Navigation Pill -->
      <div class="master-board-floating-nav">
        <a href="#/features" class="floating-explore-btn">
          <span>✨ Explore Standalone Pages</span>
          <span class="floating-explore-arrow">→</span>
        </a>
      </div>

      <!-- Active Modals -->
      <div id="modal-container">
        \${renderActiveModal(state, cycleMetrics, painMetrics)}
      </div>
    \`;
    bindEvents();
    return;
  }`;

const newRenderCheck = `  const isLandingHome = (currentRoute === 'home' || currentRoute === 'welcome' || currentRoute === '');

  if (isLandingHome) {
    document.body.classList.add('route-home');
    document.body.classList.remove('route-board');
    appContainer.innerHTML = \`
      <!-- Landing Homepage (Exact Match to User Reference Image 1) -->
      <main id="main-content" class="landing-main-view">
        \${renderLandingHomePage()}
      </main>

      <!-- Active Modals -->
      <div id="modal-container">
        \${renderActiveModal(state, cycleMetrics, painMetrics)}
      </div>
    \`;
    bindEvents();
    return;
  }

  // If user explicitly asks for /board
  if (currentRoute === 'board') {
    document.body.classList.add('route-board');
    appContainer.innerHTML = \`
      <main id="main-content" class="board-view-main">
        \${renderMasterBoard(state, cycleMetrics, painMetrics)}
      </main>
      <div id="modal-container">
        \${renderActiveModal(state, cycleMetrics, painMetrics)}
      </div>
    \`;
    bindEvents();
    return;
  }`;

content = content.replace(oldRenderCheck, newRenderCheck);

// 3. Update the header back button and logo to link to #/home instead of #/board
content = content.replace(
  `<a href="#/board" class="subpage-back-to-board-btn">\n            <span class="back-arrow">‹</span>\n            <span>Back to Master Board</span>\n          </a>\n          <a href="#/board" class="subpage-logo-text">✦ MOONLIT</a>`,
  `<a href="#/home" class="subpage-back-to-board-btn">\n            <span class="back-arrow">‹</span>\n            <span>Home</span>\n          </a>\n          <a href="#/home" class="subpage-logo-text">✦ MOONLIT</a>`
);

// 4. Update switch in renderCurrentPage to handle 'home'
content = content.replace(
  `    case 'board':\n    case 'welcome':\n    case '':\n      return renderMasterBoard(state, cycleMetrics, painMetrics);`,
  `    case 'home':\n    case 'welcome':\n    case '':\n      return renderLandingHomePage();\n    case 'board':\n      return renderMasterBoard(state, cycleMetrics, painMetrics);`
);

// 5. Replace renderCyclePage with exact pixel-perfect match to Image 2
const oldCycleMarker = `/* ==========================================================================
   PAGE 05: MY CYCLE CALENDAR (Expansive Standalone Page)
   ========================================================================== */
function renderCyclePage(state, cycleMetrics) {`;

const endCycleMarker = `/* ==========================================================================
   PAGE 06: PAIN PATTERNS (Expansive Standalone Page in Dusk Violet)`;

const cycleStartIndex = content.indexOf(oldCycleMarker);
const cycleEndIndex = content.indexOf(endCycleMarker);

if (cycleStartIndex === -1 || cycleEndIndex === -1) {
  console.error('Could not find cycle page markers', { cycleStartIndex, cycleEndIndex });
  process.exit(1);
}

const newCycleFunction = `/* ==========================================================================
   PAGE 05: MY CYCLE (Exact Pixel-by-Pixel Match to User Reference Image 2)
   ========================================================================== */
function renderCyclePage(state, cycleMetrics) {
  return \`
    <div class="cycle-page-wrapper">
      <div class="cycle-screen-card card-bg-05">
        <!-- Card Header Matching Image 2 -->
        <div class="cycle-card-header">
          <a href="#/features" class="card-nav-crumb" title="Back to Features">‹ 05</a>
          <h2 class="cycle-main-title serif-heading">My Cycle</h2>
          <p class="cycle-main-subtitle">Track. Predict. Prepare.</p>
        </div>

        <!-- White Calendar Card Matching Image 2 -->
        <div class="cycle-calendar-card">
          <div class="cycle-cal-header">
            <button class="cycle-cal-nav-arrow" id="cal-prev-btn" title="Previous Month">‹</button>
            <span class="cycle-cal-month-title serif-heading">April 2025</span>
            <button class="cycle-cal-nav-arrow" id="cal-next-btn" title="Next Month">›</button>
          </div>

          <div class="cycle-cal-weekdays">
            <span>Sun</span><span>Mon</span><span>Tue</span><span>Wed</span><span>Thu</span><span>Fri</span><span>Sat</span>
          </div>

          <div class="cycle-cal-days-grid" id="cycle-cal-grid">
            <!-- Empty Sun, Mon for April 2025 -->
            <div class="cal-day-cell empty"></div>
            <div class="cal-day-cell empty"></div>
            
            <!-- Days 1 to 7 -->
            <div class="cal-day-cell" data-day="1">1</div>
            <div class="cal-day-cell" data-day="2">2</div>
            <div class="cal-day-cell" data-day="3">3</div>
            <div class="cal-day-cell" data-day="4">4</div>
            <div class="cal-day-cell" data-day="5">5</div>
            <div class="cal-day-cell" data-day="6">6</div>
            <div class="cal-day-cell" data-day="7">7</div>
            
            <!-- Days 8 to 11: Solid Period Circles (Matching Image) -->
            <div class="cal-day-cell is-period" data-day="8" title="Period Day">8</div>
            <div class="cal-day-cell is-period" data-day="9" title="Period Day">9</div>
            <div class="cal-day-cell is-period" data-day="10" title="Period Day">10</div>
            <div class="cal-day-cell is-period" data-day="11" title="Period Day">11</div>
            <div class="cal-day-cell" data-day="12">12</div>
            <div class="cal-day-cell" data-day="13">13</div>
            
            <!-- Days 14 to 16: Dashed Predicted Circles (Matching Image) -->
            <div class="cal-day-cell is-predicted" data-day="14" title="Predicted Window">14</div>
            <div class="cal-day-cell is-predicted" data-day="15" title="Predicted Window">15</div>
            <div class="cal-day-cell is-predicted" data-day="16" title="Predicted Window">16</div>
            <div class="cal-day-cell" data-day="17">17</div>
            <div class="cal-day-cell" data-day="18">18</div>
            <div class="cal-day-cell" data-day="19">19</div>
            <div class="cal-day-cell" data-day="20">20</div>
            <div class="cal-day-cell" data-day="21">21</div>
            <div class="cal-day-cell" data-day="22">22</div>
            <div class="cal-day-cell" data-day="23">23</div>
            
            <!-- Day 24: Solid Ring Ovulation (Matching Image) -->
            <div class="cal-day-cell is-ovulation" data-day="24" title="Ovulation Day">24</div>
            <div class="cal-day-cell" data-day="25">25</div>
            <div class="cal-day-cell" data-day="26">26</div>
            <div class="cal-day-cell" data-day="27">27</div>
            <div class="cal-day-cell" data-day="28">28</div>
            <div class="cal-day-cell" data-day="29">29</div>
            <div class="cal-day-cell" data-day="30">30</div>
          </div>

          <!-- Exact Legend from Image 2 -->
          <div class="cycle-cal-legend">
            <span class="legend-item"><span class="legend-dot period-dot"></span> Period</span>
            <span class="legend-item"><span class="legend-dot predicted-dot"></span> Predicted</span>
            <span class="legend-item"><span class="legend-dot ovulation-dot"></span> Ovulation</span>
          </div>
        </div>

        <!-- Next Period Banner Matching Image 2 -->
        <div class="cycle-expected-banner">
          <div class="cycle-expected-left">
            <div class="cycle-expected-label">Next Period (expected)</div>
            <h4 class="cycle-expected-dates serif-heading">May 23 – May 27, 2026</h4>
          </div>
          <span style="font-size: 1.5rem;" title="Calendar">📅</span>
        </div>

        <!-- Footer with Girl Daydream Profile & Handwritten Note Matching Image 2 -->
        <div class="cycle-card-footer">
          <div class="cycle-art-crop-box">
            <img src="\${ILLUSTRATION_IMAGES.cycle}" alt="Girl daydream profile doodle" class="cycle-hd-doodle-img" />
          </div>
          <span class="cycle-note-handwritten handwritten-annotation">
            You got this ♡
          </span>
        </div>

        <!-- Subtle Action Button -->
        <div style="margin-top: 4px; text-align: center;">
          <button class="cycle-log-flow-action-btn" id="btn-open-cycle-log">
            + Log Flow & Symptoms
          </button>
        </div>
      </div>
    </div>
  \`;
}

`;

content = content.slice(0, cycleStartIndex) + newCycleFunction + content.slice(cycleEndIndex);

// 6. Append renderLandingHomePage() definition
const landingHomeFunction = `
/* ==========================================================================
   HOMEPAGE: LANDING HERO (Exact Match to User Reference Image 1)
   ========================================================================== */
function renderLandingHomePage() {
  return \`
    <div class="landing-page-wrapper">
      <div class="landing-hero-card">
        <!-- Top Navigation Matching Reference Image 1 -->
        <header class="landing-top-bar">
          <div class="landing-brand-group">
            <span class="landing-sparkle">✦</span>
            <div class="landing-brand-info">
              <span class="landing-brand-name">MOONLIT</span>
              <span class="landing-brand-tagline">Your body. Your rhythm. Your own little universe.</span>
            </div>
          </div>
          
          <nav class="landing-nav-links">
            <a href="#/home" class="landing-nav-item active">Home</a>
            <a href="#/features" class="landing-nav-item">Features</a>
            <a href="#/decoder" class="landing-nav-item">About</a>
            <a href="#/features" class="landing-get-started-btn">Get Started</a>
          </nav>
        </header>

        <!-- Main Body: Heading + Desc + Button on Left; HD Illustration on Right -->
        <div class="landing-hero-body">
          <div class="landing-hero-left">
            <h1 class="landing-hero-heading serif-heading">
              Understand<br>Your Body,<br>Your Way
            </h1>
            <p class="landing-hero-desc">
              MOONLIT is your safe space to explore, learn and take care of your menstrual health — especially if you have PCOS/PCOD. No judgment. No pressure. Just you.
            </p>
            <a href="#/features" class="landing-start-journey-btn">
              Start Your Journey →
            </a>
          </div>

          <div class="landing-hero-right">
            <div class="landing-art-frame">
              <img src="\${ILLUSTRATION_IMAGES.hero}" alt="Girl sitting by the window with headphones reading a book, moon and stars" class="landing-hd-art-img" />
            </div>
          </div>
        </div>
      </div>
    </div>
  \`;
}
`;

content += '\n' + landingHomeFunction;

fs.writeFileSync(filePath, content, 'utf8');
console.log('Successfully updated src/main.js with Landing Homepage and Image-2 Cycle view!');
