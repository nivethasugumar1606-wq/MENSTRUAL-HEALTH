import fs from 'fs';

const filePath = 'c:/Users/DELL/Downloads/OH - 01/src/main.js';
let content = fs.readFileSync(filePath, 'utf8');

// Replace everything from renderFeaturesPage() up to just before HELPERS & MODALS
const startMarker = '/* ==========================================================================\n   PAGE: THE 5 SIGNATURE FEATURES';
const endMarker = '/* ==========================================================================\n   HELPERS & MODALS';

const startIndex = content.indexOf(startMarker);
const endIndex = content.indexOf(endMarker);

if (startIndex === -1 || endIndex === -1) {
  console.error('Could not locate markers in src/main.js', { startIndex, endIndex });
  process.exit(1);
}

const replacementPages = `/* ==========================================================================
   PAGE: THE 5 SIGNATURE FEATURES (Expansive Standalone Page)
   ========================================================================== */
function renderFeaturesPage() {
  return \`
    <div class="standalone-page-wrapper">
      <div class="standalone-screen-card card-bg-feat">
        <!-- Hero Banner with Authentic Artwork -->
        <div class="standalone-hero-banner">
          <div class="standalone-hero-texts">
            <span class="card-nav-crumb" style="font-weight: 700; text-transform: uppercase; letter-spacing: 1.5px; font-size: 0.8rem; color: var(--plum-primary);">✦ MOONLIT Core</span>
            <h2 class="serif-heading" style="font-size: 2.2rem; line-height: 1.15; margin: 8px 0 12px; color: var(--plum-primary);">The 5 Signature Features</h2>
            <p style="font-size: 0.95rem; line-height: 1.6; color: var(--sandal-muted); max-width: 540px;">
              Designed with care, medical research, and privacy-first principles. Each space is dedicated to helping you decode your body, master food freedom, build doctor communication confidence, investigate myths, and prepare for your monthly rhythm.
            </p>
          </div>
          <div class="standalone-art-frame">
            <img src="\${ILLUSTRATION_IMAGES.features}" alt="Girl with warm coffee and flowers" />
            <span class="handwritten-annotation" style="font-size: 1.35rem; display: block; margin-top: 8px; color: var(--plum-primary);">Small steps, big changes ♡</span>
          </div>
        </div>

        <!-- 5 Feature Deep Dive Cards Grid -->
        <div class="standalone-content-grid">
          <!-- Feature 1: Decoder -->
          <div class="interactive-panel-card">
            <div style="font-size: 1.8rem; margin-bottom: 8px;">🌱</div>
            <h4>01. Body & Food Decoder</h4>
            <p style="font-size: 0.86rem; color: var(--sandal-muted); line-height: 1.55; margin-bottom: 14px;">
              Unravel the biology behind bloating, cramps, fatigue, and cravings. Learn gentle, shame-free nutrition principles that support stable blood sugar and hormone balance.
            </p>
            <div style="display: flex; gap: 8px; flex-wrap: wrap; margin-bottom: 16px;">
              <span class="view-mode-btn" style="background: var(--sandal-border-subtle); color: var(--plum-primary); font-size: 0.72rem;">Sensation Guide</span>
              <span class="view-mode-btn" style="background: var(--sandal-border-subtle); color: var(--plum-primary); font-size: 0.72rem;">Seed Cycling</span>
              <span class="view-mode-btn" style="background: var(--sandal-border-subtle); color: var(--plum-primary); font-size: 0.72rem;">Blood Sugar Balance</span>
            </div>
            <a href="#/decoder" class="hero-journey-btn" style="background: var(--plum-primary); color: #FFF; font-size: 0.8rem; padding: 8px 18px; text-decoration: none; display: inline-block;">
              Open Decoder Space →
            </a>
          </div>

          <!-- Feature 2: Privacy -->
          <div class="interactive-panel-card">
            <div style="font-size: 1.8rem; margin-bottom: 8px;">🔒</div>
            <h4>02. My Privacy, My Rules</h4>
            <p style="font-size: 0.86rem; color: var(--sandal-muted); line-height: 1.55; margin-bottom: 14px;">
              True local-only privacy. Your menstrual records are encrypted and saved solely on your personal device. No tracking cookies, no advertising brokers, and a 4-digit PIN lock.
            </p>
            <div style="display: flex; gap: 8px; flex-wrap: wrap; margin-bottom: 16px;">
              <span class="view-mode-btn" style="background: var(--sandal-border-subtle); color: var(--plum-primary); font-size: 0.72rem;">4-Digit PIN Lock</span>
              <span class="view-mode-btn" style="background: var(--sandal-border-subtle); color: var(--plum-primary); font-size: 0.72rem;">Zero Cloud Storage</span>
              <span class="view-mode-btn" style="background: var(--sandal-border-subtle); color: var(--plum-primary); font-size: 0.72rem;">Instant Data Purge</span>
            </div>
            <a href="#/privacy" class="hero-journey-btn" style="background: var(--plum-primary); color: #FFF; font-size: 0.8rem; padding: 8px 18px; text-decoration: none; display: inline-block;">
              Manage Privacy Space →
            </a>
          </div>

          <!-- Feature 3: Am I Heard? -->
          <div class="interactive-panel-card">
            <div style="font-size: 1.8rem; margin-bottom: 8px;">💬</div>
            <h4>03. Am I Being Heard?</h4>
            <p style="font-size: 0.86rem; color: var(--sandal-muted); line-height: 1.55; margin-bottom: 14px;">
              Medical self-advocacy tools. Rehearse conversations with doctors, export structured chronological symptom timelines, and prepare smart diagnostic questions.
            </p>
            <div style="display: flex; gap: 8px; flex-wrap: wrap; margin-bottom: 16px;">
              <span class="view-mode-btn" style="background: var(--sandal-border-subtle); color: var(--plum-primary); font-size: 0.72rem;">Doctor Rehearsal</span>
              <span class="view-mode-btn" style="background: var(--sandal-border-subtle); color: var(--plum-primary); font-size: 0.72rem;">Clinical Timeline</span>
              <span class="view-mode-btn" style="background: var(--sandal-border-subtle); color: var(--plum-primary); font-size: 0.72rem;">Question Checklist</span>
            </div>
            <a href="#/heard" class="hero-journey-btn" style="background: var(--plum-primary); color: #FFF; font-size: 0.8rem; padding: 8px 18px; text-decoration: none; display: inline-block;">
              Practice Conversations →
            </a>
          </div>

          <!-- Feature 4: Myth Detective -->
          <div class="interactive-panel-card">
            <div style="font-size: 1.8rem; margin-bottom: 8px;">🔍</div>
            <h4>04. MOONLIT Myth Detective</h4>
            <p style="font-size: 0.86rem; color: var(--sandal-muted); line-height: 1.55; margin-bottom: 14px;">
              Fact-check viral social media health rumors with peer-reviewed medical studies. Investigate sugar, PCOS, intense cramps, and cycle regularity without fear.
            </p>
            <div style="display: flex; gap: 8px; flex-wrap: wrap; margin-bottom: 16px;">
              <span class="view-mode-btn" style="background: var(--sandal-border-subtle); color: var(--plum-primary); font-size: 0.72rem;">Interactive Cases</span>
              <span class="view-mode-btn" style="background: var(--sandal-border-subtle); color: var(--plum-primary); font-size: 0.72rem;">Evidence Lab</span>
              <span class="view-mode-btn" style="background: var(--sandal-border-subtle); color: var(--plum-primary); font-size: 0.72rem;">Doctor Verdicts</span>
            </div>
            <a href="#/myth" class="hero-journey-btn" style="background: var(--plum-primary); color: #FFF; font-size: 0.8rem; padding: 8px 18px; text-decoration: none; display: inline-block;">
              Start Investigating →
            </a>
          </div>

          <!-- Feature 5: Cycle & Toolkit -->
          <div class="interactive-panel-card standalone-full-col">
            <div style="font-size: 1.8rem; margin-bottom: 8px;">📅 & ☕</div>
            <h4>05. Cycle Rhythm & Comfort Toolkit</h4>
            <p style="font-size: 0.86rem; color: var(--sandal-muted); line-height: 1.55; margin-bottom: 14px;">
              A compassionate tracking system that honors your unique cycle rhythm. View predicted windows, forecast Day 4 pain curves, and access instant relief stations like the 15-minute heating pad countdown timer and restorative yoga stretches.
            </p>
            <div style="display: flex; gap: 12px; flex-wrap: wrap;">
              <a href="#/cycle" class="hero-journey-btn" style="background: var(--plum-primary); color: #FFF; font-size: 0.8rem; padding: 8px 18px; text-decoration: none;">
                Open Cycle Calendar →
              </a>
              <a href="#/pain" class="hero-journey-btn" style="background: var(--plum-dark); color: #FFF; font-size: 0.8rem; padding: 8px 18px; text-decoration: none;">
                Inspect Pain Patterns →
              </a>
              <a href="#/toolkit" class="hero-journey-btn" style="background: var(--sandal-board); color: var(--plum-primary); border: 1px solid var(--plum-primary); font-size: 0.8rem; padding: 8px 18px; text-decoration: none;">
                When Pain Hits Relief Station →
              </a>
              <a href="#/prep-guide" class="hero-journey-btn" style="background: var(--sandal-card-prep); color: var(--plum-primary); font-size: 0.8rem; padding: 8px 18px; text-decoration: none;">
                7-Day Prep Guide →
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  \`;
}

/* ==========================================================================
   PAGE 01: BODY & FOOD DECODER (Expansive Standalone Page)
   ========================================================================== */
function renderDecoderPage() {
  return \`
    <div class="standalone-page-wrapper">
      <div class="standalone-screen-card card-bg-01">
        <!-- Hero Banner with Authentic Artwork -->
        <div class="standalone-hero-banner">
          <div class="standalone-hero-texts">
            <span class="card-nav-crumb" style="font-weight: 700; text-transform: uppercase; letter-spacing: 1.5px; font-size: 0.8rem;">‹ 01 Decoder</span>
            <h2 class="serif-heading" style="font-size: 2.2rem; line-height: 1.15; margin: 8px 0 12px; color: var(--plum-primary);">Body & Food Decoder</h2>
            <p style="font-size: 0.95rem; line-height: 1.6; color: var(--sandal-muted); max-width: 520px;">
              Understand cycle sensations, nourish without fear, connect hormones to daily energy, and take gentle micro-steps toward holistic menstrual wellness.
            </p>
          </div>
          <div class="standalone-art-frame">
            <img src="\${ILLUSTRATION_IMAGES.decoder}" alt="Girl sitting enjoying nourishing food" />
            <span class="handwritten-annotation" style="font-size: 1.35rem; display: block; margin-top: 8px; color: var(--plum-primary);">Good food is self care ♡</span>
          </div>
        </div>

        <!-- 4 Major Decoder Modules -->
        <div style="display: flex; flex-direction: column; gap: 28px;">
          
          <!-- Module 1: Decode My Body (Symptom Library) -->
          <div class="interactive-panel-card">
            <div style="display: flex; justify-content: space-between; align-items: baseline; margin-bottom: 12px;">
              <h4 style="font-size: 1.3rem;">🧘‍♀️ Sensation & Symptom Encyclopedia</h4>
              <span style="font-size: 0.75rem; color: var(--sandal-muted);">8 Clinically Reviewed Sensations</span>
            </div>
            <p style="font-size: 0.86rem; color: var(--sandal-muted); margin-bottom: 16px;">
              Click any sensation below to learn the physiological reason behind it and practical, gentle ways to soothe your body.
            </p>

            <div class="topics-accordion">
              \${DECODE_BODY_TOPICS.map((topic, i) => \`
                <div class="topic-card" style="margin-bottom: 10px; border-radius: var(--radius-sm); border: 1px solid var(--sandal-border); overflow: hidden; background: #FFF;">
                  <div class="topic-header" data-topic-index="\${i}" style="padding: 14px 18px; cursor: pointer; display: flex; justify-content: space-between; align-items: center; background: #FAF7F2;">
                    <div>
                      <span style="font-size: 0.68rem; text-transform: uppercase; letter-spacing: 1px; color: var(--plum-muted); font-weight: 700;">\${topic.category}</span>
                      <div class="topic-title" style="font-size: 1rem; font-weight: 700; color: var(--plum-primary); margin-top: 2px;">\${topic.title}</div>
                    </div>
                    <span style="font-size: 1.2rem; color: var(--plum-primary); font-weight: 700;">⌄</span>
                  </div>
                  <div class="topic-body" id="topic-body-\${i}" style="\${i === 0 ? 'display: block;' : 'display: none;'} padding: 16px 18px; font-size: 0.88rem; line-height: 1.6; color: var(--plum-primary); border-top: 1px solid var(--sandal-border);">
                    \${topic.content}
                  </div>
                </div>
              \`).join('')}
            </div>
          </div>

          <!-- Module 2: Food Freedom -->
          <div class="interactive-panel-card">
            <div style="display: flex; justify-content: space-between; align-items: baseline; margin-bottom: 12px;">
              <h4 style="font-size: 1.3rem;">🍴 Food Freedom & Hormone Nutrition</h4>
              <span style="font-size: 0.75rem; color: var(--sandal-muted);">Nourish Without Shame</span>
            </div>
            <p style="font-size: 0.86rem; color: var(--sandal-muted); margin-bottom: 16px;">
              No restrictive diets or moralizing food. Here is how balanced nourishment supports your hormones, insulin sensitivity, and mood.
            </p>

            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;">
              \${FOOD_FREEDOM_GUIDES.map(guide => \`
                <div style="background: #FFF; border: 1px solid var(--sandal-border); padding: 18px; border-radius: var(--radius-md);">
                  <span style="font-size: 0.72rem; font-weight: 700; text-transform: uppercase; color: var(--plum-primary); background: var(--sandal-border-subtle); padding: 2px 8px; border-radius: var(--radius-full);">\${guide.subtitle}</span>
                  <h5 class="serif-heading" style="font-size: 1.1rem; margin: 8px 0 6px; color: var(--plum-primary);">\${guide.title}</h5>
                  <p style="font-size: 0.84rem; line-height: 1.55; color: var(--sandal-muted);">\${guide.content}</p>
                </div>
              \`).join('')}
            </div>
          </div>

          <!-- Module 3: Connect the Dots (The 4 Hormonal Seasons) -->
          <div class="interactive-panel-card">
            <h4 style="font-size: 1.3rem; margin-bottom: 8px;">✨ Connect the Dots: The 4 Cycle Seasons</h4>
            <p style="font-size: 0.86rem; color: var(--sandal-muted); margin-bottom: 18px;">
              Your energy, focus, and appetite shift naturally across the 4 biological phases. Understand each season:
            </p>

            <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px;">
              <div style="background: #FFF; border: 1px solid var(--sandal-border); padding: 14px; border-radius: var(--radius-sm);">
                <div style="font-weight: 700; font-size: 0.85rem; color: var(--plum-primary);">❄️ Winter</div>
                <div style="font-size: 0.72rem; color: var(--plum-muted); font-weight: 600; margin-bottom: 6px;">Menstrual (Days 1–5)</div>
                <p style="font-size: 0.78rem; line-height: 1.45; color: var(--sandal-muted);">Low estrogen & progesterone. Ideal for resting, warm broths, iron-rich foods, and quiet solitude.</p>
              </div>

              <div style="background: #FFF; border: 1px solid var(--sandal-border); padding: 14px; border-radius: var(--radius-sm);">
                <div style="font-weight: 700; font-size: 0.85rem; color: var(--plum-primary);">🌱 Spring</div>
                <div style="font-size: 0.72rem; color: var(--plum-muted); font-weight: 600; margin-bottom: 6px;">Follicular (Days 6–13)</div>
                <p style="font-size: 0.78rem; line-height: 1.45; color: var(--sandal-muted);">Estrogen rises, boosting brain clarity, social energy, and workout stamina. Fresh light meals.</p>
              </div>

              <div style="background: #FFF; border: 1px solid var(--sandal-border); padding: 14px; border-radius: var(--radius-sm);">
                <div style="font-weight: 700; font-size: 0.85rem; color: var(--plum-primary);">☀️ Summer</div>
                <div style="font-size: 0.72rem; color: var(--plum-muted); font-weight: 600; margin-bottom: 6px;">Ovulatory (Days 14–16)</div>
                <p style="font-size: 0.78rem; line-height: 1.45; color: var(--sandal-muted);">Peak estrogen & testosterone. High confidence, communication, and libido. Fiber & hydration.</p>
              </div>

              <div style="background: #FFF; border: 1px solid var(--sandal-border); padding: 14px; border-radius: var(--radius-sm);">
                <div style="font-weight: 700; font-size: 0.85rem; color: var(--plum-primary);">🍂 Autumn</div>
                <div style="font-size: 0.72rem; color: var(--plum-muted); font-weight: 600; margin-bottom: 6px;">Luteal (Days 17–28)</div>
                <p style="font-size: 0.78rem; line-height: 1.45; color: var(--sandal-muted);">Progesterone dominates. Nesting instinct, higher caloric needs (+200 kcal), magnesium & rest.</p>
              </div>
            </div>
          </div>

        </div>
      </div>
    </div>
  \`;
}

/* ==========================================================================
   PAGE 02: MY PRIVACY, MY RULES (Expansive Standalone Page)
   ========================================================================== */
function renderPrivacyPage() {
  const state = store.getState();
  const logsCount = state.cycles.length;
  const painCount = state.painLogs.length;

  return \`
    <div class="standalone-page-wrapper">
      <div class="standalone-screen-card card-bg-02">
        <!-- Hero Banner with Authentic Artwork -->
        <div class="standalone-hero-banner">
          <div class="standalone-hero-texts">
            <span class="card-nav-crumb" style="font-weight: 700; text-transform: uppercase; letter-spacing: 1.5px; font-size: 0.8rem;">‹ 02 Privacy</span>
            <h2 class="serif-heading" style="font-size: 2.2rem; line-height: 1.15; margin: 8px 0 12px; color: var(--plum-primary);">My Privacy, My Rules</h2>
            <p style="font-size: 0.95rem; line-height: 1.6; color: var(--sandal-muted); max-width: 520px;">
              Your data belongs solely to you. We do not sell, synchronize, or transmit your menstrual health history to any corporate cloud or advertising network.
            </p>
          </div>
          <div class="standalone-art-frame">
            <img src="\${ILLUSTRATION_IMAGES.privacy}" alt="Girl working on laptop with cat and plants" />
            <span class="handwritten-annotation" style="font-size: 1.35rem; display: block; margin-top: 8px; color: var(--plum-primary);">Your privacy matters ♡</span>
          </div>
        </div>

        <!-- 4 Security Modules Grid -->
        <div class="standalone-content-grid">
          
          <!-- Module 1: App Lock & PIN -->
          <div class="interactive-panel-card">
            <h4>🔒 App Lock & 4-Digit Security</h4>
            <p style="font-size: 0.86rem; color: var(--sandal-muted); margin-bottom: 16px;">
              Require a private 4-digit PIN every time MOONLIT is opened to shield your cycle dates and doctor notes from prying eyes.
            </p>
            <div style="background: #FAF7F2; padding: 14px 18px; border-radius: var(--radius-sm); border: 1px solid var(--sandal-border); margin-bottom: 16px;">
              <div style="display: flex; justify-content: space-between; align-items: center;">
                <span style="font-weight: 600; font-size: 0.88rem;">Current Status:</span>
                <span class="view-mode-btn" style="background: \${state.privacySettings.appLockEnabled ? '#2E7D32' : '#757575'}; color: #FFF; font-size: 0.75rem;">
                  \${state.privacySettings.appLockEnabled ? 'Active (PIN Set)' : 'Disabled'}
                </span>
              </div>
            </div>
            <div style="display: flex; gap: 10px;">
              <a href="#/privacy-lock" class="hero-journey-btn" style="background: var(--plum-primary); color: #FFF; font-size: 0.8rem; padding: 8px 18px; text-decoration: none;">
                \${state.privacySettings.appLockEnabled ? 'Change PIN Code' : 'Set Up Private PIN'}
              </a>
              <button class="quick-action-btn" id="btn-quick-lock-test" style="border-color: var(--plum-primary); color: var(--plum-primary);">
                Test Lock Screen
              </button>
            </div>
          </div>

          <!-- Module 2: Data Transparency -->
          <div class="interactive-panel-card">
            <h4>💾 Local Storage Transparency</h4>
            <p style="font-size: 0.86rem; color: var(--sandal-muted); margin-bottom: 16px;">
              Full audit of everything stored in your local browser sandbox. Zero bytes exist on remote servers.
            </p>
            <div style="display: flex; flex-direction: column; gap: 8px; font-size: 0.84rem; margin-bottom: 16px;">
              <div style="display: flex; justify-content: space-between; padding: 6px 0; border-bottom: 1px solid var(--sandal-border);">
                <span>Recorded Cycles:</span>
                <strong>\${logsCount} records</strong>
              </div>
              <div style="display: flex; justify-content: space-between; padding: 6px 0; border-bottom: 1px solid var(--sandal-border);">
                <span>Daily Pain Logs:</span>
                <strong>\${painCount} logs</strong>
              </div>
              <div style="display: flex; justify-content: space-between; padding: 6px 0; border-bottom: 1px solid var(--sandal-border);">
                <span>Third-Party Trackers:</span>
                <strong style="color: #2E7D32;">0 (Zero Trackers)</strong>
              </div>
            </div>
            <a href="#/privacy-storage" class="quick-action-btn" style="border-color: var(--plum-primary); color: var(--plum-primary); text-decoration: none; display: inline-block;">
              Inspect Storage Schema →
            </a>
          </div>

          <!-- Module 3: Export & Purge -->
          <div class="interactive-panel-card">
            <h4>📋 Export / Complete Data Erasure</h4>
            <p style="font-size: 0.86rem; color: var(--sandal-muted); margin-bottom: 16px;">
              Download a complete JSON/CSV copy of all your tracked health history, or perform an irreversible cryptographic wipe.
            </p>
            <div style="display: flex; gap: 10px; flex-wrap: wrap;">
              <a href="#/privacy-export" class="hero-journey-btn" style="background: var(--plum-primary); color: #FFF; font-size: 0.8rem; padding: 8px 18px; text-decoration: none;">
                Download Data Backup
              </a>
              <button class="quick-action-btn" id="btn-purge-all-data" style="border-color: #C62828; color: #C62828;">
                Erase All Data
              </button>
            </div>
          </div>

          <!-- Module 4: Notification Discretion -->
          <div class="interactive-panel-card">
            <h4>🔔 Notification Stealth Preview</h4>
            <p style="font-size: 0.86rem; color: var(--sandal-muted); margin-bottom: 16px;">
              Choose between explicit medical reminders or discreet stealth mode alerts for your lock screen.
            </p>
            <div style="background: #FAF7F2; padding: 12px 16px; border-radius: var(--radius-sm); border: 1px solid var(--sandal-border); margin-bottom: 16px;">
              <div style="font-size: 0.72rem; color: var(--plum-muted); text-transform: uppercase; font-weight: 700;">Sample Lock Screen Alert</div>
              <div style="font-size: 0.88rem; font-weight: 600; color: var(--plum-primary); margin-top: 4px;">"MOONLIT: Self-care check-in scheduled for today."</div>
            </div>
            <a href="#/privacy-notif" class="quick-action-btn" style="border-color: var(--plum-primary); color: var(--plum-primary); text-decoration: none; display: inline-block;">
              Configure Discretion Settings →
            </a>
          </div>

        </div>
      </div>
    </div>
  \`;
}

/* ==========================================================================
   PAGE 03: AM I BEING HEARD? (Expansive Standalone Page in Dusk Violet)
   ========================================================================== */
function renderHeardPage() {
  const state = store.getState();

  return \`
    <div class="standalone-page-wrapper">
      <div class="standalone-screen-card card-bg-plum">
        <!-- Hero Banner with Authentic Artwork -->
        <div class="standalone-hero-banner">
          <div class="standalone-hero-texts">
            <span class="card-nav-crumb" style="font-weight: 700; text-transform: uppercase; letter-spacing: 1.5px; font-size: 0.8rem; color: var(--sandal-board);">‹ 03 Am I Being Heard?</span>
            <h2 class="serif-heading" style="font-size: 2.2rem; line-height: 1.15; margin: 8px 0 12px; color: var(--sandal-board);">Am I Being Heard?</h2>
            <p style="font-size: 0.95rem; line-height: 1.6; color: var(--plum-muted); max-width: 520px;">
              Better conversations, brighter care. You have the right to have your pain acknowledged and investigated. Here are practical medical self-advocacy tools.
            </p>
          </div>
          <div class="standalone-art-frame">
            <img src="\${ILLUSTRATION_IMAGES.heard}" alt="Girl holding medical notebook looking up" />
            <span class="handwritten-annotation" style="font-size: 1.35rem; display: block; margin-top: 8px; color: var(--sandal-board);">You're not alone ♡</span>
          </div>
        </div>

        <!-- 4 Communication Modules Grid -->
        <div class="standalone-content-grid">
          
          <!-- Module 1: Conversation Practice -->
          <div class="interactive-panel-card">
            <h4>💬 Doctor Conversation Simulator</h4>
            <p style="font-size: 0.86rem; color: var(--sandal-muted); margin-bottom: 14px;">
              Practice responding to dismissive phrases like "Period pain is normal" or "You're just stressed" with evidence-based assertive statements.
            </p>
            <div style="background: #FAF7F2; padding: 12px 14px; border-radius: var(--radius-sm); border-left: 3px solid var(--plum-primary); margin-bottom: 14px; font-size: 0.84rem;">
              <strong>Assertive Response:</strong> "I understand mild cramps occur, but my pain reaches 8/10 and prevents school attendance. Could we order a pelvic ultrasound to check for secondary causes?"
            </div>
            <a href="#/heard-rehearsal" class="hero-journey-btn" style="background: var(--plum-primary); color: #FFF; font-size: 0.8rem; padding: 8px 18px; text-decoration: none; display: inline-block;">
              Rehearse Full Dialogue →
            </a>
          </div>

          <!-- Module 2: Symptom Timeline -->
          <div class="interactive-panel-card">
            <h4>✏️ Clinical Symptom Timeline</h4>
            <p style="font-size: 0.86rem; color: var(--sandal-muted); margin-bottom: 14px;">
              Doctors respond best to structured, chronological data. View and copy a clear bulleted summary of your pain duration, peak days, and medication efficacy.
            </p>
            <div style="background: #FAF7F2; padding: 12px 14px; border-radius: var(--radius-sm); margin-bottom: 14px; font-size: 0.82rem; color: var(--plum-primary);">
              • Average Bleeding Duration: 5 days<br />
              • Pain Intensity Peak: Day 4 (Severe, 8/10)<br />
              • Primary Symptoms: Cramps, Lower Back Pain, Nausea
            </div>
            <a href="#/heard-timeline" class="hero-journey-btn" style="background: var(--plum-primary); color: #FFF; font-size: 0.8rem; padding: 8px 18px; text-decoration: none; display: inline-block;">
              Generate Clinical Summary →
            </a>
          </div>

          <!-- Module 3: Doctor Questions -->
          <div class="interactive-panel-card">
            <h4>🩺 Essential Questions for Your Doctor</h4>
            <p style="font-size: 0.86rem; color: var(--sandal-muted); margin-bottom: 14px;">
              12 crucial diagnostic questions covering PCOS blood markers, ultrasound scans, iron panel testing, and hormonal birth control side-effects.
            </p>
            <a href="#/heard-questions" class="hero-journey-btn" style="background: var(--plum-primary); color: #FFF; font-size: 0.8rem; padding: 8px 18px; text-decoration: none; display: inline-block;">
              View Questions Checklist →
            </a>
          </div>

          <!-- Module 4: Appointment Notes -->
          <div class="interactive-panel-card">
            <h4>📋 Appointment Notes & Next Steps</h4>
            <p style="font-size: 0.86rem; color: var(--sandal-muted); margin-bottom: 14px;">
              Record what the clinician recommended, tests ordered, prescription instructions, and scheduled follow-up dates in one secure place.
            </p>
            <a href="#/heard-notes" class="hero-journey-btn" style="background: var(--plum-primary); color: #FFF; font-size: 0.8rem; padding: 8px 18px; text-decoration: none; display: inline-block;">
              Open Consultation Notes →
            </a>
          </div>

        </div>
      </div>
    </div>
  \`;
}

/* ==========================================================================
   PAGE 04: MOONLIT MYTH DETECTIVE (Expansive Standalone Page)
   ========================================================================== */
function renderMythPage() {
  return \`
    <div class="standalone-page-wrapper">
      <div class="standalone-screen-card card-bg-04">
        <!-- Hero Banner with Authentic Artwork -->
        <div class="standalone-hero-banner">
          <div class="standalone-hero-texts">
            <span class="card-nav-crumb" style="font-weight: 700; text-transform: uppercase; letter-spacing: 1.5px; font-size: 0.8rem; color: var(--plum-primary);">‹ 04 Myth Detective</span>
            <h2 class="serif-heading" style="font-size: 2.2rem; line-height: 1.15; margin: 8px 0 12px; color: var(--plum-primary);">MOONLIT Myth Detective</h2>
            <p style="font-size: 0.95rem; line-height: 1.6; color: var(--sandal-muted); max-width: 520px;">
              Question. Explore. Make informed choices. We examine viral social media health claims through clinical endocrinology and peer-reviewed research.
            </p>
          </div>
          <div class="standalone-art-frame">
            <img src="\${ILLUSTRATION_IMAGES.myth}" alt="Girl investigating with magnifying glass" />
            <span class="handwritten-annotation" style="font-size: 1.35rem; display: block; margin-top: 8px; color: var(--plum-primary);">Truth doesn't hurt ♡</span>
          </div>
        </div>

        <!-- Myth Cases Grid -->
        <div style="margin-bottom: 24px;">
          <div style="display: flex; justify-content: space-between; align-items: baseline; margin-bottom: 14px;">
            <h4 style="font-size: 1.3rem;">🔍 Active Clinical Investigations</h4>
            <span style="font-size: 0.78rem; color: var(--sandal-muted);">5 Evidence-Based Cases</span>
          </div>

          <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;">
            \${MYTH_CASES.map(c => \`
              <div class="interactive-panel-card" style="display: flex; flex-direction: column; justify-content: space-between;">
                <div>
                  <span style="font-size: 0.72rem; font-weight: 700; background: var(--sandal-border-subtle); color: var(--plum-primary); padding: 3px 8px; border-radius: var(--radius-full);">\${c.tag}</span>
                  <h5 class="serif-heading" style="font-size: 1.2rem; margin: 10px 0 6px; color: var(--plum-primary);">\${c.title}</h5>
                  <p style="font-size: 0.85rem; font-style: italic; color: var(--sandal-muted); margin-bottom: 14px;">"\${c.claim}"</p>
                </div>
                <a href="#/myth-play/\${c.id}" class="hero-journey-btn" style="background: var(--plum-primary); color: #FFF; font-size: 0.8rem; padding: 8px 18px; text-decoration: none; align-self: flex-start;">
                  Inspect Clues & Evidence →
                </a>
              </div>
            \`).join('')}
          </div>
        </div>
      </div>
    </div>
  \`;
}

/* ==========================================================================
   PAGE 05: MY CYCLE CALENDAR (Expansive Standalone Page)
   ========================================================================== */
function renderCyclePage(state, cycleMetrics) {
  return \`
    <div class="standalone-page-wrapper">
      <div class="standalone-screen-card card-bg-05">
        <!-- Hero Banner with Authentic Artwork -->
        <div class="standalone-hero-banner">
          <div class="standalone-hero-texts">
            <span class="card-nav-crumb" style="font-weight: 700; text-transform: uppercase; letter-spacing: 1.5px; font-size: 0.8rem; color: var(--plum-primary);">‹ 05 My Cycle</span>
            <h2 class="serif-heading" style="font-size: 2.2rem; line-height: 1.15; margin: 8px 0 12px; color: var(--plum-primary);">My Cycle Calendar</h2>
            <p style="font-size: 0.95rem; line-height: 1.6; color: var(--sandal-muted); max-width: 520px;">
              Track. Predict. Prepare. Discover your cycle rhythm across all four biological phases without shame or clinical anxiety.
            </p>
          </div>
          <div class="standalone-art-frame">
            <img src="\${ILLUSTRATION_IMAGES.cycle}" alt="Girl serene profile daydreaming" />
            <span class="handwritten-annotation" style="font-size: 1.35rem; display: block; margin-top: 8px; color: var(--plum-primary);">You got this ♡</span>
          </div>
        </div>

        <!-- Calendar + Cycle Metrics Grid -->
        <div style="display: grid; grid-template-columns: 1.3fr 1fr; gap: 24px;">
          
          <!-- Left: Big Interactive Calendar -->
          <div class="interactive-panel-card">
            <div class="calendar-month-header" style="margin-bottom: 16px;">
              <button class="calendar-nav-arrow" id="cal-prev-month">‹</button>
              <span class="calendar-month-title" id="cal-month-name" style="font-size: 1.25rem; font-weight: 700;">April 2025</span>
              <button class="calendar-nav-arrow" id="cal-next-month">›</button>
            </div>

            <div class="calendar-weekdays-row" style="margin-bottom: 10px; font-weight: 600;">
              <span>Sun</span><span>Mon</span><span>Tue</span><span>Wed</span><span>Thu</span><span>Fri</span><span>Sat</span>
            </div>

            <div class="calendar-days-grid" id="cal-days-grid" style="min-height: 240px;">
              \${renderCalendarGridDays(2025, 3, state.cycles)}
            </div>

            <div class="calendar-legend" style="margin-top: 16px; border-top: 1px solid var(--sandal-border); padding-top: 12px;">
              <div class="legend-item"><span class="legend-dot period"></span><span>Period Day</span></div>
              <div class="legend-item"><span class="legend-dot predicted"></span><span>Predicted Window</span></div>
              <div class="legend-item"><span class="legend-dot selected"></span><span>Ovulation Day</span></div>
            </div>
          </div>

          <!-- Right: Cycle Statistics & Phase Intelligence -->
          <div style="display: flex; flex-direction: column; gap: 16px;">
            <!-- Next Period Card -->
            <div class="interactive-panel-card" style="background: var(--plum-primary); color: #FFF;">
              <div style="font-size: 0.75rem; text-transform: uppercase; letter-spacing: 1px; color: var(--plum-muted);">Next Expected Period</div>
              <div style="font-size: 1.45rem; font-family: var(--font-serif); font-weight: 700; margin: 4px 0 8px; color: #FAF6F0;">
                \${cycleMetrics.nextPeriodWindow || 'May 2 – May 6, 2025'}
              </div>
              <div style="font-size: 0.82rem; color: var(--plum-muted); line-height: 1.45;">
                \${cycleMetrics.durationInsight}
              </div>
            </div>

            <!-- Cycle Metrics Summary -->
            <div class="interactive-panel-card">
              <h5 class="serif-heading" style="font-size: 1.1rem; margin-bottom: 12px;">Your Cycle Health Metrics</h5>
              <div style="display: flex; flex-direction: column; gap: 8px; font-size: 0.85rem;">
                <div style="display: flex; justify-content: space-between; padding: 6px 0; border-bottom: 1px solid var(--sandal-border);">
                  <span>Average Cycle Length:</span>
                  <strong>\${cycleMetrics.averageCycleLength} days</strong>
                </div>
                <div style="display: flex; justify-content: space-between; padding: 6px 0; border-bottom: 1px solid var(--sandal-border);">
                  <span>Average Period Duration:</span>
                  <strong>\${cycleMetrics.averagePeriodDuration} days</strong>
                </div>
                <div style="display: flex; justify-content: space-between; padding: 6px 0; border-bottom: 1px solid var(--sandal-border);">
                  <span>Regularity Status:</span>
                  <strong style="color: #2E7D32;">\${cycleMetrics.regularity}</strong>
                </div>
              </div>

              <button class="hero-journey-btn" id="btn-log-period-cal" style="background: var(--plum-primary); color: #FFF; width: 100%; justify-content: center; margin-top: 16px; border: none; cursor: pointer; padding: 10px;">
                Log Today's Flow +
              </button>
            </div>
          </div>

        </div>
      </div>
    </div>
  \`;
}

/* ==========================================================================
   PAGE 06: PAIN PATTERNS (Expansive Standalone Page in Dusk Violet)
   ========================================================================== */
function renderPainPage(painMetrics) {
  return \`
    <div class="standalone-page-wrapper">
      <div class="standalone-screen-card card-bg-plum">
        <!-- Hero Banner with Authentic Artwork -->
        <div class="standalone-hero-banner">
          <div class="standalone-hero-texts">
            <span class="card-nav-crumb" style="font-weight: 700; text-transform: uppercase; letter-spacing: 1.5px; font-size: 0.8rem; color: var(--sandal-board);">‹ 06 Pain Patterns</span>
            <h2 class="serif-heading" style="font-size: 2.2rem; line-height: 1.15; margin: 8px 0 12px; color: var(--sandal-board);">Pain Patterns</h2>
            <p style="font-size: 0.95rem; line-height: 1.6; color: var(--plum-muted); max-width: 520px;">
              Find patterns. Prepare better. Understand when your prostaglandins peak so you can start comforting heat therapy and magnesium ahead of time.
            </p>
          </div>
          <div class="standalone-art-frame">
            <img src="\${ILLUSTRATION_IMAGES.painSprig}" alt="Botanical sprig" />
            <span class="handwritten-annotation" style="font-size: 1.35rem; display: block; margin-top: 8px; color: var(--sandal-board);">Your body gives you signals ♡</span>
          </div>
        </div>

        <!-- Pain Curve & Symptom Co-occurrence Grid -->
        <div style="display: grid; grid-template-columns: 1.2fr 1fr; gap: 24px;">
          
          <!-- Left: Big Average Pain Chart -->
          <div class="interactive-panel-card">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;">
              <h4>Average Pain Curve Across 7 Days</h4>
              <span class="pain-badge-pill" style="background: var(--plum-primary); color: #FFF;">Day 4 Peak</span>
            </div>
            
            <div style="width: 100%; height: 160px; margin-bottom: 16px;">
              \${renderPosterPainCurveSVG()}
            </div>

            <p style="font-size: 0.84rem; color: var(--sandal-muted); line-height: 1.5;">
              In 3 of your last 4 recorded cycles, <strong>Day 4</strong> exhibited the highest concentration of uterine cramping. Starting heating therapy on Day 3 can significantly buffer this peak.
            </p>
          </div>

          <!-- Right: Symptom Co-occurrence Matrix -->
          <div class="interactive-panel-card">
            <h4>Most Likely Symptom Timeline</h4>
            <p style="font-size: 0.84rem; color: var(--sandal-muted); margin-bottom: 14px;">
              How different discomforts cluster during bleeding days:
            </p>

            <div style="display: flex; flex-direction: column; gap: 10px; font-size: 0.86rem;">
              <div style="display: flex; justify-content: space-between; padding: 10px 14px; background: #FAF7F2; border-radius: var(--radius-sm);">
                <span>○ Uterine Cramps</span>
                <strong>Peak: Day 1 & 2</strong>
              </div>
              <div style="display: flex; justify-content: space-between; padding: 10px 14px; background: #FAF7F2; border-radius: var(--radius-sm);">
                <span>○ Sacral / Back Pain</span>
                <strong>Peak: Day 2</strong>
              </div>
              <div style="display: flex; justify-content: space-between; padding: 10px 14px; background: #FAF7F2; border-radius: var(--radius-sm);">
                <span>○ Tension Headache</span>
                <strong>Peak: Day 3</strong>
              </div>
              <div style="display: flex; justify-content: space-between; padding: 10px 14px; background: #FAF7F2; border-radius: var(--radius-sm);">
                <span>○ Fatigue & Heavy Limbs</span>
                <strong>Peak: Day 4</strong>
              </div>
            </div>

            <a href="#/toolkit" class="hero-journey-btn" style="background: var(--plum-primary); color: #FFF; width: 100%; justify-content: center; margin-top: 16px; text-decoration: none;">
              Open Pain Relief Toolkit →
            </a>
          </div>

        </div>
      </div>
    </div>
  \`;
}

/* ==========================================================================
   PAGE 07: WHAT'S CHANGED? (Expansive Standalone Page)
   ========================================================================== */
function renderChangedPage() {
  return \`
    <div class="standalone-page-wrapper">
      <div class="standalone-screen-card card-bg-07">
        <!-- Hero Banner with Authentic Artwork -->
        <div class="standalone-hero-banner">
          <div class="standalone-hero-texts">
            <span class="card-nav-crumb" style="font-weight: 700; text-transform: uppercase; letter-spacing: 1.5px; font-size: 0.8rem; color: var(--plum-primary);">‹ 07 Routine Shifts</span>
            <h2 class="serif-heading" style="font-size: 2.2rem; line-height: 1.15; margin: 8px 0 12px; color: var(--plum-primary);">What's Changed?</h2>
            <p style="font-size: 0.95rem; line-height: 1.6; color: var(--sandal-muted); max-width: 520px;">
              Your health, your journey, your growth. Track routine and lifestyle variables to discover how sleep, stress, and nutrition correlate with cycle regularity.
            </p>
          </div>
          <div class="standalone-art-frame">
            <img src="\${ILLUSTRATION_IMAGES.changed}" alt="Girl doodle profile" />
            <span class="handwritten-annotation" style="font-size: 1.35rem; display: block; margin-top: 8px; color: var(--plum-primary);">You're doing great ♡</span>
          </div>
        </div>

        <!-- Factor Toggles + Insights -->
        <div class="standalone-content-grid">
          
          <!-- Factor Toggles -->
          <div class="interactive-panel-card">
            <h4>Track Today's Influencing Factors</h4>
            <p style="font-size: 0.85rem; color: var(--sandal-muted); margin-bottom: 16px;">
              Click to toggle the variables active in your day:
            </p>

            <div class="chips-grid-2x3" style="margin-bottom: 18px;">
              <button class="change-chip-btn \${selectedFactors.has('Sleep') ? 'active' : ''}" data-factor="Sleep">
                <span>🌙</span><span>Sleep Disrupted</span>
              </button>
              <button class="change-chip-btn \${selectedFactors.has('Stress / Mood') ? 'active' : ''}" data-factor="Stress / Mood">
                <span>🧠</span><span>High Stress</span>
              </button>
              <button class="change-chip-btn \${selectedFactors.has('Exercise / Activity') ? 'active' : ''}" data-factor="Exercise / Activity">
                <span>🏃</span><span>Heavy Workout</span>
              </button>
              <button class="change-chip-btn \${selectedFactors.has('Food / Diet') ? 'active' : ''}" data-factor="Food / Diet">
                <span>🥗</span><span>Dietary Changes</span>
              </button>
              <button class="change-chip-btn \${selectedFactors.has('New medication') ? 'active' : ''}" data-factor="New medication">
                <span>💊</span><span>New Medication</span>
              </button>
              <button class="change-chip-btn \${selectedFactors.has('Other') ? 'active' : ''}" data-factor="Other">
                <span>✨</span><span>Other Factor</span>
              </button>
            </div>

            <input type="text" class="optional-note-input" id="input-routine-note" placeholder="Add custom reflection..." value="School exams deadline and less sleep" />
          </div>

          <!-- Correlation Insights Panel -->
          <div class="interactive-panel-card">
            <h4>Observed Clinical Correlation</h4>
            <div style="background: #FAF7F2; padding: 16px; border-radius: var(--radius-sm); border-left: 3px solid var(--plum-primary); margin-bottom: 14px; font-size: 0.88rem; line-height: 1.55;">
              <strong>💡 Correlation Found:</strong> High stress scores coincided with a 1.8-point increase in Day 4 cramp intensity across your last 3 cycles. Cortisol elevation can sensitize peripheral pain receptors.
            </div>

            <div class="change-quote-box">
              <span style="font-size: 0.85rem; line-height: 1.55;">
                "Progress isn't always visible, but it's always happening. When life gets stressful, prioritize extra sleep and warm tea." ♡
              </span>
            </div>
          </div>

        </div>
      </div>
    </div>
  \`;
}

/* ==========================================================================
   PAGE 08: WHEN PAIN HITS (Expansive Standalone Page in Dusk Violet)
   ========================================================================== */
function renderToolkitPage(state) {
  return \`
    <div class="standalone-page-wrapper">
      <div class="standalone-screen-card card-bg-plum">
        <!-- Hero Banner with Authentic Artwork -->
        <div class="standalone-hero-banner">
          <div class="standalone-hero-texts">
            <span class="card-nav-crumb" style="font-weight: 700; text-transform: uppercase; letter-spacing: 1.5px; font-size: 0.8rem; color: var(--sandal-board);">‹ 08 Comfort Toolkit</span>
            <h2 class="serif-heading" style="font-size: 2.2rem; line-height: 1.15; margin: 8px 0 12px; color: var(--sandal-board);">When Pain Hits</h2>
            <p style="font-size: 0.95rem; line-height: 1.6; color: var(--plum-muted); max-width: 520px;">
              Gentle relief. Powerful you. Immediate comforting modalities designed to relax uterine smooth muscles and quiet your nervous system.
            </p>
          </div>
          <div class="standalone-art-frame">
            <img src="\${ILLUSTRATION_IMAGES.painSprig}" alt="Botanical sprig" />
            <span class="handwritten-annotation" style="font-size: 1.35rem; display: block; margin-top: 8px; color: var(--sandal-board);">Take care... You deserve it ♡</span>
          </div>
        </div>

        <!-- 5 Relief Stations Grid -->
        <div class="standalone-content-grid">
          
          <!-- Station 1: Warm Compress Timer -->
          <div class="interactive-panel-card">
            <h4>🔥 15-Minute Heat Therapy Session</h4>
            <p style="font-size: 0.85rem; color: var(--sandal-muted); margin-bottom: 14px;">
              Applying 40°C heat to the lower abdomen increases blood flow and relaxes smooth muscle spasm as effectively as over-the-counter pain relievers.
            </p>

            \${comfortTimerSec > 0 ? \`
              <div class="active-timer-card" style="background: #FAF7F2; border-radius: var(--radius-sm); padding: 18px; text-align: center; margin-bottom: 14px;">
                <div style="font-size: 0.72rem; text-transform: uppercase; letter-spacing: 1px; color: var(--plum-muted);">Warm Compress Timer Active</div>
                <div class="timer-digits" style="font-size: 2.2rem; font-weight: 700; color: var(--plum-primary); margin: 6px 0;">\${formatTimer(comfortTimerSec)}</div>
                <button class="quick-action-btn" id="btn-stop-timer" style="border-color: var(--plum-primary); color: var(--plum-primary);">Pause Timer</button>
              </div>
            \` : \`
              <button class="hero-journey-btn" id="btn-start-comfort-timer" style="background: var(--plum-primary); color: #FFF; width: 100%; justify-content: center; border: none; cursor: pointer; padding: 10px; margin-bottom: 14px;">
                ⏱ Start 15-Minute Soothing Timer
              </button>
            \`}
          </div>

          <!-- Station 2: Restorative Stretches -->
          <div class="interactive-panel-card">
            <h4>🧘 Restorative Pelvic Stretches</h4>
            <p style="font-size: 0.85rem; color: var(--sandal-muted); margin-bottom: 14px;">
              Gently release pelvic floor tension without elevating heart rate:
            </p>

            <div style="display: flex; flex-direction: column; gap: 8px; font-size: 0.84rem;">
              <div style="padding: 8px 12px; background: #FAF7F2; border-radius: var(--radius-xs);">
                <strong>1. Wide-Knee Child's Pose (Balasana):</strong> Fold torso forward between knees, breathe into lower back for 2 minutes.
              </div>
              <div style="padding: 8px 12px; background: #FAF7F2; border-radius: var(--radius-xs);">
                <strong>2. Reclined Butterfly (Supta Baddha Konasana):</strong> Soles of feet together, knees open, cushion under lower back.
              </div>
              <div style="padding: 8px 12px; background: #FAF7F2; border-radius: var(--radius-xs);">
                <strong>3. Gentle Cat-Cow:</strong> Slow spinal waves to mobilize pelvic fascia.
              </div>
            </div>
          </div>

          <!-- Station 3: Warm Bath & Epsom Salts -->
          <div class="interactive-panel-card">
            <h4>🛁 Warm Bath & Hydrotherapy</h4>
            <p style="font-size: 0.85rem; color: var(--sandal-muted); line-height: 1.55;">
              Soak in a 38°C bath infused with 2 cups of Epsom salts (magnesium sulfate) and 4 drops of lavender oil to soothe cramps and induce restorative sleep.
            </p>
          </div>

          <!-- Station 4: Hydration & Teas -->
          <div class="interactive-panel-card">
            <h4>💧 Cramp-Easing Herbal Teas</h4>
            <p style="font-size: 0.85rem; color: var(--sandal-muted); line-height: 1.55;">
              Sip warm chamomile (anti-inflammatory glycine), fresh ginger root tea (prostaglandin inhibitor), or peppermint tea to alleviate nausea and abdominal bloating.
            </p>
          </div>

        </div>
      </div>
    </div>
  \`;
}

/* ==========================================================================
   PAGE 09: YOUR 7-DAY PREP GUIDE (Expansive Standalone Page)
   ========================================================================== */
function renderPrepGuidePage(state) {
  return \`
    <div class="standalone-page-wrapper">
      <div class="standalone-screen-card card-bg-prep">
        <!-- Hero Banner with Authentic Artwork -->
        <div class="standalone-hero-banner">
          <div class="standalone-hero-texts">
            <span class="card-nav-crumb" style="font-weight: 700; text-transform: uppercase; letter-spacing: 1.5px; font-size: 0.8rem; color: var(--plum-primary);">✦ Period Readiness</span>
            <h2 class="serif-heading" style="font-size: 2.2rem; line-height: 1.15; margin: 8px 0 12px; color: var(--plum-primary);">Your 7-Day Prep Guide</h2>
            <p style="font-size: 0.95rem; line-height: 1.6; color: var(--sandal-muted); max-width: 520px;">
              Get ready, feel more in control. A step-by-step roadmap for the 7 days before your period arrives so you feel safe, comfortable, and prepared.
            </p>
          </div>
          <div class="standalone-art-frame">
            <img src="\${ILLUSTRATION_IMAGES.prep}" alt="Girl with tote bag and flowers" />
            <span class="handwritten-annotation" style="font-size: 1.35rem; display: block; margin-top: 8px; color: var(--plum-primary);">Same girl... Stronger always ♡</span>
          </div>
        </div>

        <!-- 7 Days Stepper Cards Grid -->
        <div style="display: grid; grid-template-columns: repeat(7, 1fr); gap: 10px; margin-bottom: 24px;">
          \${['day-7', 'day-6', 'day-5', 'day-4', 'day-3', 'day-2', 'day-1'].map((key, idx) => {
            const isDone = state.prepGuideChecks[key];
            const dayNum = -(7 - idx);
            const labels = ['Plan', 'Food', 'Self-care', 'Track', 'Rest', 'Reflect', 'Ready'];
            return \`
              <div class="prep-step-bubble" data-prep-key="\${key}" style="background: #FFF; border: 1px solid var(--sandal-border); padding: 12px 6px; border-radius: var(--radius-sm); text-align: center; cursor: pointer;">
                <div class="circle-num \${isDone ? 'done' : ''}" style="margin: 0 auto 6px; width: 32px; height: 32px; font-size: 0.85rem;">\${isDone ? '✓' : Math.abs(dayNum)}</div>
                <div style="font-size: 0.72rem; font-weight: 700; color: var(--plum-primary);">Day \${dayNum}</div>
                <div style="font-size: 0.65rem; color: var(--sandal-muted);">\${labels[idx]}</div>
              </div>
            \`;
          }).join('')}
        </div>

        <!-- Do's & Things to Consider Grid -->
        <div class="standalone-content-grid">
          
          <div class="interactive-panel-card">
            <h4>✓ Do's: Nourishing Preparations</h4>
            <ul class="checklist-ul" style="margin-top: 12px; gap: 8px;">
              <li class="checklist-li"><span style="color: #2E7D32; font-weight: 700; font-size: 1.1rem;">✓</span><span>Stay hydrated (2–3L warm water daily)</span></li>
              <li class="checklist-li"><span style="color: #2E7D32; font-weight: 700; font-size: 1.1rem;">✓</span><span>Eat iron-rich foods (spinach, lentils, seeds)</span></li>
              <li class="checklist-li"><span style="color: #2E7D32; font-weight: 700; font-size: 1.1rem;">✓</span><span>Get 8–9 hours of deep restorative sleep</span></li>
              <li class="checklist-li"><span style="color: #2E7D32; font-weight: 700; font-size: 1.1rem;">✓</span><span>Keep a pain relief kit & heating pad handy</span></li>
              <li class="checklist-li"><span style="color: #2E7D32; font-weight: 700; font-size: 1.1rem;">✓</span><span>Stock up on preferred pads, tampons, or period cups</span></li>
            </ul>
          </div>

          <div class="interactive-panel-card">
            <h4>○ Things to Consider</h4>
            <ul class="checklist-ul" style="margin-top: 12px; gap: 8px;">
              <li class="checklist-li"><span style="color: var(--sandal-muted); font-size: 1.1rem;">○</span><span>Switch to light movement (walking, yin yoga)</span></li>
              <li class="checklist-li"><span style="color: var(--sandal-muted); font-size: 1.1rem;">○</span><span>Manage emotional stress & clear busy schedules</span></li>
              <li class="checklist-li"><span style="color: var(--sandal-muted); font-size: 1.1rem;">○</span><span>Limit excess caffeine & refined sugar</span></li>
              <li class="checklist-li"><span style="color: var(--sandal-muted); font-size: 1.1rem;">○</span><span>Consult your doctor if cramps disrupt school/work</span></li>
              <li class="checklist-li"><span style="color: var(--sandal-muted); font-size: 1.1rem;">○</span><span>Be endlessly kind to yourself</span></li>
            </ul>
          </div>

        </div>
      </div>
    </div>
  \`;
}
`;

const updatedContent = content.slice(0, startIndex) + replacementPages + '\n\n' + content.slice(endIndex);
fs.writeFileSync(filePath, updatedContent);
console.log('Successfully updated all standalone pages in src/main.js to be BIGGER with MORE CONTENT!');
