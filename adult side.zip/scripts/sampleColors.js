import sharp from 'sharp';

const imgPath = 'C:/Users/DELL/.gemini/antigravity-ide/brain/6bdda1c2-6460-4c7d-8a6f-ea07428974b9/.user_uploaded/media_1792765786465.jpg';

async function sampleColors() {
  const { data, info } = await sharp(imgPath).raw().toBuffer({ resolveWithObject: true });
  
  function getHex(x, y) {
    const idx = (y * info.width + x) * info.channels;
    const r = data[idx].toString(16).padStart(2, '0');
    const g = data[idx + 1].toString(16).padStart(2, '0');
    const b = data[idx + 2].toString(16).padStart(2, '0');
    return `#${r}${g}${b}`.toUpperCase();
  }

  console.log('Hero background (x=100, y=100):', getHex(100, 100));
  console.log('Hero background (x=200, y=200):', getHex(200, 200));
  console.log('5 Features background (x=550, y=100):', getHex(550, 100));
  console.log('Card 01 background (x=80, y=320):', getHex(80, 320));
  console.log('Card 02 background (x=240, y=320):', getHex(240, 320));
  console.log('Card 03 background (x=400, y=320):', getHex(400, 320));
  console.log('Card 04 background (x=550, y=320):', getHex(550, 320));
  console.log('Card 05 background (x=80, y=650):', getHex(80, 650));
  console.log('Card 06 background (x=240, y=650):', getHex(240, 650));
  console.log('Card 07 background (x=400, y=650):', getHex(400, 650));
  console.log('Card 08 background (x=550, y=650):', getHex(550, 650));
  console.log('Prep Guide background (x=250, y=960):', getHex(250, 960));
  console.log('Poster outer canvas/margin (x=2, y=2):', getHex(2, 2));
}

sampleColors().catch(console.error);
