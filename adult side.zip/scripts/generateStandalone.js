import fs from 'fs';
import path from 'path';

// Find the built assets in dist/assets
const distDir = path.resolve('dist');
const assetsDir = path.join(distDir, 'assets');

if (fs.existsSync(assetsDir)) {
  const files = fs.readdirSync(assetsDir);
  const cssFile = files.find(f => f.endsWith('.css'));
  const jsFile = files.find(f => f.endsWith('.js'));

  if (cssFile && jsFile) {
    const cssContent = fs.readFileSync(path.join(assetsDir, cssFile), 'utf8');
    const jsContent = fs.readFileSync(path.join(assetsDir, jsFile), 'utf8');

    const html = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>NUTURA — Your body. Your rhythm. Your private wellness sanctuary.</title>
  <meta name="description" content="NUTURA is a private, evidence-informed digital sanctuary for menstrual wellness, cycle tracking, endocrine awareness, and clinical consultation readiness." />
  <meta name="theme-color" content="#473E69" />

  <!-- Google Fonts: Playfair Display, Plus Jakarta Sans, Caveat -->
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=Caveat:wght@400..700&family=Playfair+Display:ital,wght@0,400..700;1,400..700&family=Plus+Jakarta+Sans:ital,wght@0,300..800;1,300..800&display=swap" rel="stylesheet" />

  <!-- Embedded Zero-Dependency Stylesheet -->
  <style>
${cssContent}
  </style>
</head>
<body>
  <div id="app"></div>

  <!-- Embedded Zero-Dependency Application Logic -->
  <script>
${jsContent}
  </script>
</body>
</html>`;

    fs.writeFileSync('standalone.html', html, 'utf8');
    console.log('✅ Successfully generated self-contained standalone.html (works with direct double-click on file:// protocol)!');
  }
}
