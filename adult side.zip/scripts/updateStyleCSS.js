import fs from 'fs';

// 1. Update src/style.css with Landing Homepage and Pixel-Perfect Cycle styles
const cssPath = 'c:/Users/DELL/Downloads/OH - 01/src/style.css';
let css = fs.readFileSync(cssPath, 'utf8');

const newStyles = `
/* ==========================================================================
   HOMEPAGE LANDING HERO (Pixel-Accurate to Image 1)
   ========================================================================== */
.landing-page-wrapper {
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 40px 20px;
  background: radial-gradient(circle at 50% 30%, #2B2338 0%, #171220 100%);
}

.landing-hero-card {
  width: 100%;
  max-width: 960px;
  background-color: var(--plum-primary); /* #473E69 Amethyst Dusk Violet */
  border-radius: 28px;
  padding: 38px 46px;
  color: #FFFFFF;
  box-shadow: 0 24px 60px rgba(0, 0, 0, 0.45);
  display: flex;
  flex-direction: column;
  gap: 32px;
  position: relative;
  overflow: hidden;
}

.landing-top-bar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  flex-wrap: wrap;
  gap: 16px;
}

.landing-brand-group {
  display: flex;
  align-items: center;
  gap: 12px;
}

.landing-sparkle {
  font-size: 1.6rem;
  color: #FAF6F0;
  line-height: 1;
}

.landing-brand-info {
  display: flex;
  flex-direction: column;
}

.landing-brand-name {
  font-family: var(--font-serif);
  font-size: 1.6rem;
  font-weight: 700;
  letter-spacing: 2.5px;
  color: #FFFFFF;
  line-height: 1.1;
}

.landing-brand-tagline {
  font-size: 0.76rem;
  color: var(--plum-muted);
  letter-spacing: 0.2px;
  margin-top: 2px;
}

.landing-nav-links {
  display: flex;
  align-items: center;
  gap: 22px;
}

.landing-nav-item {
  color: #FAF6F0;
  text-decoration: none;
  font-size: 0.92rem;
  font-weight: 500;
  transition: opacity 0.2s ease;
}

.landing-nav-item:hover,
.landing-nav-item.active {
  opacity: 1;
}

.landing-get-started-btn {
  background-color: #FAF6F0;
  color: var(--plum-primary);
  font-size: 0.88rem;
  font-weight: 700;
  padding: 9px 24px;
  border-radius: var(--radius-full);
  text-decoration: none;
  box-shadow: 0 4px 14px rgba(0, 0, 0, 0.2);
  transition: all 0.2s ease;
  display: inline-block;
}

.landing-get-started-btn:hover {
  transform: translateY(-2px);
  background-color: #FFFFFF;
  box-shadow: 0 8px 20px rgba(0, 0, 0, 0.28);
}

.landing-hero-body {
  display: grid;
  grid-template-columns: 1fr 1.1fr;
  gap: 36px;
  align-items: center;
}

.landing-hero-heading {
  font-family: var(--font-serif);
  font-size: 2.85rem;
  line-height: 1.18;
  font-weight: 700;
  color: #FFFFFF;
  margin-bottom: 20px;
  letter-spacing: -0.5px;
}

.landing-hero-desc {
  font-size: 0.98rem;
  line-height: 1.65;
  color: var(--plum-muted);
  margin-bottom: 28px;
  max-width: 420px;
}

.landing-start-journey-btn {
  display: inline-flex;
  align-items: center;
  gap: 10px;
  background-color: #FAF6F0;
  color: var(--plum-primary);
  font-size: 0.95rem;
  font-weight: 700;
  padding: 13px 28px;
  border-radius: var(--radius-full);
  text-decoration: none;
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.2);
  transition: all 0.2s ease;
}

.landing-start-journey-btn:hover {
  transform: translateY(-2px);
  background-color: #FFFFFF;
  box-shadow: 0 12px 28px rgba(0, 0, 0, 0.3);
}

.landing-art-frame {
  display: flex;
  justify-content: center;
  align-items: center;
  background: rgba(255, 255, 255, 0.03);
  border-radius: 20px;
  padding: 8px;
}

.landing-hd-art-img {
  width: 100%;
  max-width: 480px;
  height: auto;
  border-radius: 16px;
  object-fit: contain;
  image-rendering: -webkit-optimize-contrast;
  image-rendering: crisp-edges;
  filter: contrast(1.04);
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.25);
}

@media (max-width: 820px) {
  .landing-hero-body {
    grid-template-columns: 1fr;
    text-align: center;
  }
  .landing-hero-desc {
    margin: 0 auto 24px;
  }
  .landing-top-bar {
    justify-content: center;
  }
}

/* ==========================================================================
   MY CYCLE PAGE (Pixel-Accurate to Image 2)
   ========================================================================== */
.cycle-page-wrapper {
  min-height: calc(100vh - 70px);
  display: flex;
  justify-content: center;
  align-items: flex-start;
  padding: 36px 20px 60px;
  background: radial-gradient(circle at 50% 20%, #2B2338 0%, #191422 100%);
}

.cycle-screen-card {
  width: 100%;
  max-width: 380px;
  background-color: var(--sandal-card-05); /* #F1E4D4 Warm Almond */
  border-radius: 24px;
  padding: 26px 22px;
  box-shadow: 0 16px 45px rgba(0, 0, 0, 0.25);
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.cycle-card-header .card-nav-crumb {
  font-size: 0.85rem;
  font-weight: 700;
  color: var(--plum-primary);
  text-decoration: none;
  display: inline-block;
  margin-bottom: 4px;
}

.cycle-main-title {
  font-family: var(--font-serif);
  font-size: 2.15rem;
  font-weight: 700;
  color: var(--plum-primary);
  margin: 0 0 2px;
  line-height: 1.1;
}

.cycle-main-subtitle {
  font-size: 0.88rem;
  color: var(--sandal-muted);
  margin: 0 0 8px;
}

.cycle-calendar-card {
  background: #FFFFFF;
  border-radius: 20px;
  padding: 20px 16px 16px;
  box-shadow: 0 4px 18px rgba(71, 62, 105, 0.06);
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.cycle-cal-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 6px;
}

.cycle-cal-nav-arrow {
  background: none;
  border: none;
  font-size: 1.3rem;
  color: var(--plum-primary);
  cursor: pointer;
  padding: 4px 8px;
  font-weight: 700;
  line-height: 1;
}

.cycle-cal-month-title {
  font-family: var(--font-serif);
  font-size: 1.3rem;
  font-weight: 700;
  color: var(--plum-primary);
}

.cycle-cal-weekdays {
  display: grid;
  grid-template-columns: repeat(7, 1fr);
  text-align: center;
  font-size: 0.78rem;
  font-weight: 500;
  color: var(--sandal-muted);
  padding: 4px 0;
}

.cycle-cal-days-grid {
  display: grid;
  grid-template-columns: repeat(7, 1fr);
  row-gap: 8px;
  column-gap: 2px;
  text-align: center;
  font-size: 0.88rem;
}

.cal-day-cell {
  height: 35px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: var(--plum-primary);
  border-radius: 50%;
  cursor: pointer;
  user-select: none;
  transition: all 0.15s ease;
}

.cal-day-cell.empty {
  cursor: default;
}

.cal-day-cell:not(.empty):hover {
  background: rgba(71, 62, 105, 0.08);
}

/* 1. Period: Solid Dark Purple Circle (White Text) */
.cal-day-cell.is-period {
  background-color: var(--plum-primary);
  color: #FFFFFF;
  font-weight: 700;
  border-radius: 50%;
  width: 35px;
  height: 35px;
  margin: 0 auto;
  box-shadow: 0 2px 8px rgba(71, 62, 105, 0.3);
}

/* 2. Predicted: Dashed Circle Outline */
.cal-day-cell.is-predicted {
  border: 1.6px dashed var(--plum-primary);
  color: var(--plum-primary);
  font-weight: 600;
  border-radius: 50%;
  width: 35px;
  height: 35px;
  margin: 0 auto;
}

/* 3. Ovulation: Solid Circle Outline */
.cal-day-cell.is-ovulation {
  border: 1.6px solid var(--plum-primary);
  color: var(--plum-primary);
  font-weight: 600;
  border-radius: 50%;
  width: 35px;
  height: 35px;
  margin: 0 auto;
}

.cycle-cal-legend {
  display: flex;
  align-items: center;
  justify-content: space-around;
  font-size: 0.78rem;
  color: var(--sandal-muted);
  margin-top: 8px;
  padding-top: 12px;
  border-top: 1px solid var(--sandal-border-subtle);
}

.legend-item {
  display: inline-flex;
  align-items: center;
  gap: 5px;
}

.legend-dot {
  display: inline-block;
  border-radius: 50%;
}

.legend-dot.period-dot {
  width: 9px;
  height: 9px;
  background-color: var(--plum-primary);
}

.legend-dot.predicted-dot {
  width: 9px;
  height: 9px;
  border: 1.4px dashed var(--plum-primary);
}

.legend-dot.ovulation-dot {
  width: 9px;
  height: 9px;
  border: 1.4px solid var(--plum-primary);
}

.cycle-expected-banner {
  background: #F8EFE6;
  border-radius: 14px;
  padding: 14px 18px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  border: 1px solid var(--sandal-border-subtle);
}

.cycle-expected-label {
  font-size: 0.78rem;
  color: var(--sandal-muted);
  font-weight: 500;
  margin-bottom: 2px;
}

.cycle-expected-dates {
  font-family: var(--font-serif);
  font-size: 1.25rem;
  font-weight: 700;
  color: var(--plum-primary);
  margin: 0;
}

.cycle-card-footer {
  display: flex;
  align-items: flex-end;
  justify-content: space-between;
  margin-top: 6px;
}

.cycle-art-crop-box {
  width: 105px;
}

.cycle-hd-doodle-img {
  width: 100%;
  height: auto;
  object-fit: contain;
  image-rendering: -webkit-optimize-contrast;
  image-rendering: crisp-edges;
}

.cycle-note-handwritten {
  font-family: var(--font-hand);
  font-size: 1.45rem;
  color: var(--plum-primary);
  transform: rotate(3deg);
  margin-bottom: 8px;
}

.cycle-log-flow-action-btn {
  background: var(--plum-primary);
  color: #FFFFFF;
  border: none;
  font-size: 0.85rem;
  font-weight: 600;
  padding: 10px 20px;
  border-radius: var(--radius-full);
  cursor: pointer;
  transition: all 0.2s ease;
}

.cycle-log-flow-action-btn:hover {
  background: var(--plum-dark);
  transform: translateY(-1px);
}

/* Image HD Rendering optimizations */
img.authentic-doodle-img,
.standalone-art-frame img,
.landing-hd-art-img,
.cycle-hd-doodle-img {
  image-rendering: -webkit-optimize-contrast;
  image-rendering: crisp-edges;
  filter: contrast(1.05);
}
`;

fs.writeFileSync(cssPath, css + '\n' + newStyles, 'utf8');
console.log('Successfully appended Homepage & Cycle styles to src/style.css');
